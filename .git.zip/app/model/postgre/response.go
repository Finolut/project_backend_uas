package model

// MetaInfo contains pagination and filtering information
type MetaInfo struct {
	Page   int    `json:"page"`
	Limit  int    `json:"limit"`
	Total  int    `json:"total"`
	Pages  int    `json:"pages"`
	SortBy string `json:"sortBy"`
	Order  string `json:"order"`
	Search string `json:"search"`
}

// StudentListResponse represents the response structure for student endpoints with pagination
type StudentListResponse struct {
	Data []Student `json:"data"` // Diperbaiki: Mengacu pada model Student (dari alumni.go yang direfaktor)
	Meta MetaInfo  `json:"meta"`
}

// AchievementReferenceResponse represents the response structure for achievement reference endpoints with pagination
type AchievementReferenceResponse struct {
	Data []AchievementReference `json:"data"` // Diperbaiki: Mengacu pada model AchievementReference (dari pekerjaan_alumni.go yang direfaktor)
	Meta MetaInfo               `json:"meta"`
}

// PaginationParams represents query parameters for pagination, sorting, and search
type PaginationParams struct {
	Page   int    `json:"page"`
	Limit  int    `json:"limit"`
	SortBy string `json:"sortBy"`
	Order  string `json:"order"`
	Search string `json:"search"`
}
