package model

import (
	"time"
)

// --- Achievement Related Tables (SRS 3.1.7) ---

// AchievementReference represents the achievement_references table
type AchievementReference struct {
	ID                 string     `json:"id" db:"id"`                                     // UUID
	StudentID          string     `json:"student_id" db:"student_id"`                     // FK to students.id (UUID)
	MongoAchievementID string     `json:"mongo_achievement_id" db:"mongo_achievement_id"` // MongoDB ObjectID (string)
	Status             string     `json:"status" db:"status"`                             // ENUM('draft', 'submitted', 'verified', 'rejected')
	SubmittedAt        *time.Time `json:"submitted_at" db:"submitted_at"`
	VerifiedAt         *time.Time `json:"verified_at" db:"verified_at"`
	VerifiedBy         *string    `json:"verified_by" db:"verified_by"` // User ID (UUID)
	RejectionNote      *string    `json:"rejection_note" db:"rejection_note"`
	CreatedAt          time.Time  `json:"created_at" db:"created_at"`
	UpdatedAt          time.Time  `json:"updated_at" db:"updated_at"`
}

// Catatan: Model lama PekerjaanAlumni dan request-request terkait telah dihapus.
// Jika Anda perlu model untuk data dinamis di MongoDB (SRS 3.2), Anda harus melihat model MongoDB.
