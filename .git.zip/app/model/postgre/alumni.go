package model

import "time"

// --- RBAC Tables (SRS 3.1.2) ---

// Role represents the roles table (SRS 3.1.2)
type Role struct {
	ID          string    `json:"id" db:"id"` // UUID
	Name        string    `json:"name" db:"name"`
	Description *string   `json:"description" db:"description"`
	CreatedAt   time.Time `json:"created_at" db:"created_at"`
}

// --- User Relation Tables (SRS 3.1.5 & 3.1.6) ---

// Student represents the students table and links to User
type Student struct {
	ID           string    `json:"id" db:"id"`                 // UUID
	UserID       string    `json:"user_id" db:"user_id"`       // FK to users
	StudentID    string    `json:"student_id" db:"student_id"` // NIM
	ProgramStudy *string   `json:"program_study" db:"program_study"`
	AcademicYear *string   `json:"academic_year" db:"academic_year"`
	AdvisorID    *string   `json:"advisor_id" db:"advisor_id"` // FK to lecturers.id (UUID)
	CreatedAt    time.Time `json:"created_at" db:"created_at"`
}

// Lecturer represents the lecturers table and links to User
type Lecturer struct {
	ID         string    `json:"id" db:"id"`           // UUID
	UserID     string    `json:"user_id" db:"user_id"` // FK to users
	LecturerID string    `json:"lecturer_id" db:"lecturer_id"`
	Department *string   `json:"department" db:"department"`
	CreatedAt  time.Time `json:"created_at" db:"created_at"`
}

// --- Request/Response for Student (replacing Alumni) ---

// RegisterStudentRequest menggantikan CreateAlumniRequest
type RegisterStudentRequest struct {
	Username     string  `json:"username" validate:"required"`
	Password     string  `json:"password" validate:"required,min=6"`
	Email        string  `json:"email" validate:"required,email"`
	FullName     string  `json:"full_name" validate:"required"`
	StudentID    string  `json:"student_id" validate:"required"` // NIM
	ProgramStudy *string `json:"program_study"`
	AcademicYear *string `json:"academic_year"`
}

// UpdateStudentRequest menggantikan UpdateAlumniRequest
type UpdateStudentRequest struct {
	FullName     string  `json:"full_name" validate:"required"`
	Email        string  `json:"email" validate:"required,email"`
	ProgramStudy *string `json:"program_study"`
	AcademicYear *string `json:"academic_year"`
}

// AlumniStatistics disesuaikan untuk model baru
type AlumniStatistics struct {
	TotalUsers         int            `json:"total_users"`
	TotalStudents      int            `json:"total_students"`
	TotalLecturers     int            `json:"total_lecturers"`
	StudentsByStudy    map[string]int `json:"students_by_study"`
	StudentsByAcadYear map[string]int `json:"students_by_acad_year"`
}
