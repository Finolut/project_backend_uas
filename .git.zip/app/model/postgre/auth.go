package model

import (
	"time"

	"github.com/golang-jwt/jwt/v5"
)

// --- User Core (from SRS 3.1.1) ---

type User struct {
	ID           string    `json:"id" db:"id"` // UUID
	Username     string    `json:"username" db:"username"`
	Email        string    `json:"email" db:"email"`
	PasswordHash string    `json:"-" db:"password_hash"`
	FullName     string    `json:"full_name" db:"full_name"`
	RoleID       string    `json:"role_id" db:"role_id"` // UUID
	IsActive     bool      `json:"is_active" db:"is_active"`
	CreatedAt    time.Time `json:"created_at" db:"created_at"`
	UpdatedAt    time.Time `json:"updated_at" db:"updated_at"`
}

type LoginRequest struct {
	Username string `json:"username" validate:"required"`
	Password string `json:"password" validate:"required"`
}

type LoginResponse struct {
	User  User   `json:"user"`
	Token string `json:"token"`
}

type JWTClaims struct {
	UserID   string `json:"user_id"` // User ID (UUID)
	Username string `json:"username"`
	RoleName string `json:"role_name"` // Role Name (e.g., "Admin", "Mahasiswa")
	RoleID   string `json:"role_id"`   // Role ID (UUID)
	jwt.RegisteredClaims
}

// Mengganti AlumniLoginRequest
type StudentLoginRequest struct {
	NIM      string `json:"nim" validate:"required"`
	Password string `json:"password" validate:"required"`
}

// Mengganti AlumniLoginResponse
type StudentLoginResponse struct {
	Student StudentView `json:"student"`
	Token   string      `json:"token"`
}

// Mengganti AlumniJWTClaims
type StudentJWTClaims struct {
	UserID   string `json:"user_id"` // user_id dari tabel users (UUID)
	NIM      string `json:"nim"`     // student_id dari tabel students
	Nama     string `json:"nama"`    // full_name dari tabel users
	Email    string `json:"email"`
	RoleName string `json:"role_name"`
	jwt.RegisteredClaims
}

// Struktur untuk kompatibilitas response/tampilan mahasiswa (mengganti model Alumni lama)
type StudentView struct {
	ID        string    `json:"id"`
	NIM       string    `json:"nim"`
	Nama      string    `json:"nama"`
	Email     string    `json:"email"`
	Role      string    `json:"role"`
	CreatedAt time.Time `json:"created_at"`
	UpdatedAt time.Time `json:"updated_at"`
}
