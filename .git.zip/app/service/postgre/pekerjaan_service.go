package service

import (
	"database/sql"

	"github.com/gofiber/fiber/v2"
)

// Semua layanan yang berhubungan dengan 'PekerjaanAlumni' telah dihapus
// dan diganti dengan placeholder 'Not Implemented' karena model data berubah
// dari Pekerjaan Alumni menjadi Achievement Reference.

func GetAllPekerjaanService(c *fiber.Ctx, db *sql.DB) error {
	return c.Status(fiber.StatusNotImplemented).JSON(fiber.Map{
		"message": "Endpoint untuk Pekerjaan Alumni telah dinonaktifkan (SRS baru)",
		"success": false,
	})
}

func GetPekerjaanByIDService(c *fiber.Ctx, db *sql.DB) error {
	return c.Status(fiber.StatusNotImplemented).JSON(fiber.Map{
		"message": "Endpoint untuk Pekerjaan Alumni telah dinonaktifkan (SRS baru)",
		"success": false,
	})
}

func GetPekerjaanByAlumniIDService(c *fiber.Ctx, db *sql.DB) error {
	return c.Status(fiber.StatusNotImplemented).JSON(fiber.Map{
		"message": "Endpoint untuk Pekerjaan Alumni telah dinonaktifkan (SRS baru)",
		"success": false,
	})
}

func CreatePekerjaanService(c *fiber.Ctx, db *sql.DB) error {
	return c.Status(fiber.StatusNotImplemented).JSON(fiber.Map{
		"message": "Endpoint untuk Pekerjaan Alumni telah dinonaktifkan (SRS baru)",
		"success": false,
	})
}

func UpdatePekerjaanService(c *fiber.Ctx, db *sql.DB) error {
	return c.Status(fiber.StatusNotImplemented).JSON(fiber.Map{
		"message": "Endpoint untuk Pekerjaan Alumni telah dinonaktifkan (SRS baru)",
		"success": false,
	})
}

func DeletePekerjaanService(c *fiber.Ctx, db *sql.DB) error {
	return c.Status(fiber.StatusNotImplemented).JSON(fiber.Map{
		"message": "Endpoint untuk Pekerjaan Alumni telah dinonaktifkan (SRS baru)",
		"success": false,
	})
}

func GetAllPekerjaanWithPaginationService(c *fiber.Ctx, db *sql.DB) error {
	return c.Status(fiber.StatusNotImplemented).JSON(fiber.Map{
		"message": "Endpoint untuk Pekerjaan Alumni telah dinonaktifkan (SRS baru)",
		"success": false,
	})
}

func SoftDeletePekerjaanService(c *fiber.Ctx, db *sql.DB) error {
	return c.Status(fiber.StatusNotImplemented).JSON(fiber.Map{
		"message": "Endpoint untuk Pekerjaan Alumni telah dinonaktifkan (SRS baru)",
		"success": false,
	})
}

func RestorePekerjaanService(c *fiber.Ctx, db *sql.DB) error {
	return c.Status(fiber.StatusNotImplemented).JSON(fiber.Map{
		"message": "Endpoint untuk Pekerjaan Alumni telah dinonaktifkan (SRS baru)",
		"success": false,
	})
}

func HardDeletePekerjaanService(c *fiber.Ctx, db *sql.DB) error {
	return c.Status(fiber.StatusNotImplemented).JSON(fiber.Map{
		"message": "Endpoint untuk Pekerjaan Alumni telah dinonaktifkan (SRS baru)",
		"success": false,
	})
}
