package service

import (
	model "clean-arch/app/model/postgre"
	repository "clean-arch/app/repository/postgre"
	utils "clean-arch/utils/postgre"
	"database/sql"
	"log"
	"os"
	"strings"

	"github.com/gofiber/fiber/v2"
)

// Mengganti CheckAlumniService
func CheckStudentService(c *fiber.Ctx, db *sql.DB) error {
	key := c.Params("key")
	if key != os.Getenv("API_KEY") {
		return c.Status(fiber.StatusUnauthorized).JSON(fiber.Map{
			"message": "Key tidak valid",
			"success": false,
		})
	}

	nim := c.FormValue("nim")
	if nim == "" {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"message": "NIM wajib diisi",
			"success": false,
		})
	}

	student, user, err := repository.CheckStudentByStudentID(db, nim)
	if err != nil {
		if err == sql.ErrNoRows {
			return c.Status(fiber.StatusOK).JSON(fiber.Map{
				"message":   "Mahasiswa tidak ditemukan",
				"success":   true,
				"isStudent": false,
			})
		}
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
			"message": "Gagal cek mahasiswa: " + err.Error(),
			"success": false,
		})
	}

	// Prepare minimal response for compatibility (menggunakan struktur StudentView)
	studentResponse := model.StudentView{
		ID:    user.ID,
		NIM:   student.StudentID,
		Nama:  user.FullName,
		Email: user.Email,
		Role:  user.RoleID,
	}

	return c.Status(fiber.StatusOK).JSON(fiber.Map{
		"message":   "Berhasil mendapatkan data mahasiswa",
		"success":   true,
		"isStudent": true,
		"student":   studentResponse,
	})
}

// Mengganti GetAllAlumniService
func GetAllStudentsService(c *fiber.Ctx, db *sql.DB) error {
	username := c.Locals("username").(string)
	log.Printf("User %s mengakses GET /api/students", username)

	students, err := repository.GetAllStudents(db)
	if err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
			"message": "Gagal mengambil data mahasiswa: " + err.Error(),
			"success": false,
		})
	}

	return c.Status(fiber.StatusOK).JSON(fiber.Map{
		"message": "Berhasil mengambil data mahasiswa",
		"success": true,
		"data":    students,
	})
}

// Mengganti GetAlumniByIDService
func GetStudentByIDService(c *fiber.Ctx, db *sql.DB) error {
	username := c.Locals("username").(string)
	id := c.Params("id") // User ID (UUID string)

	log.Printf("User %s mengakses GET /api/students/%s", username, id)

	user, err := repository.GetUserByID(db, id)
	if err != nil {
		if err == sql.ErrNoRows {
			return c.Status(fiber.StatusNotFound).JSON(fiber.Map{
				"message": "Mahasiswa/User tidak ditemukan",
				"success": false,
			})
		}
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
			"message": "Gagal mengambil data user: " + err.Error(),
			"success": false,
		})
	}

	user.PasswordHash = ""

	student, err := repository.GetStudentByUserID(db, id)
	if err != nil && err != sql.ErrNoRows {
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
			"message": "Gagal mengambil data mahasiswa: " + err.Error(),
			"success": false,
		})
	}

	return c.Status(fiber.StatusOK).JSON(fiber.Map{
		"message": "Berhasil mengambil data mahasiswa",
		"success": true,
		"data":    fiber.Map{"user": user, "student_profile": student},
	})
}

// Mengganti CreateAlumniService
func CreateStudentService(c *fiber.Ctx, db *sql.DB) error {
	username := c.Locals("username").(string)
	log.Printf("Admin %s menambah mahasiswa baru", username)

	var req model.RegisterStudentRequest

	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"message": "Format data tidak valid: " + err.Error(),
			"success": false,
		})
	}

	if req.StudentID == "" || req.FullName == "" || req.Email == "" || req.Username == "" || req.Password == "" {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"message": "Semua field wajib diisi",
			"success": false,
		})
	}

	// Find Student Role ID
	role, err := repository.GetRoleByName(db, "Mahasiswa")
	if err != nil {
		return c.Status(500).JSON(fiber.Map{"error": "Role Mahasiswa tidak ditemukan"})
	}

	hashedPassword, err := utils.HashPassword(req.Password)
	if err != nil {
		return c.Status(500).JSON(fiber.Map{"error": "Gagal hash password"})
	}

	user, student, err := repository.CreateUserAndStudent(db, req, hashedPassword, role.ID)
	if err != nil {
		if strings.Contains(err.Error(), "username atau email sudah terdaftar") || strings.Contains(err.Error(), "NIM sudah terdaftar") {
			return c.Status(409).JSON(fiber.Map{"error": err.Error()})
		}
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
			"message": "Gagal menambah mahasiswa: " + err.Error(),
			"success": false,
		})
	}

	user.PasswordHash = ""

	return c.Status(fiber.StatusCreated).JSON(fiber.Map{
		"message": "Mahasiswa berhasil ditambahkan",
		"success": true,
		"data":    fiber.Map{"user": user, "student_profile": student},
	})
}

// Mengganti UpdateAlumniService
func UpdateStudentService(c *fiber.Ctx, db *sql.DB) error {
	username := c.Locals("username").(string)
	id := c.Params("id") // User ID (UUID string)

	log.Printf("Admin %s mengupdate mahasiswa/user ID %s", username, id)

	var req model.UpdateStudentRequest

	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"message": "Format data tidak valid: " + err.Error(),
			"success": false,
		})
	}

	if req.FullName == "" || req.Email == "" {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"message": "Nama lengkap dan email wajib diisi",
			"success": false,
		})
	}

	user, student, err := repository.UpdateUserAndStudent(db, id, req)
	if err != nil {
		if err == sql.ErrNoRows {
			return c.Status(fiber.StatusNotFound).JSON(fiber.Map{
				"message": "Mahasiswa/User tidak ditemukan",
				"success": false,
			})
		}
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
			"message": "Gagal mengupdate mahasiswa: " + err.Error(),
			"success": false,
		})
	}

	user.PasswordHash = ""

	return c.Status(fiber.StatusOK).JSON(fiber.Map{
		"message": "Mahasiswa berhasil diupdate",
		"success": true,
		"data":    fiber.Map{"user": user, "student_profile": student},
	})
}

// Mengganti DeleteAlumniService
func DeleteStudentService(c *fiber.Ctx, db *sql.DB) error {
	username := c.Locals("username").(string)
	id := c.Params("id") // User ID (UUID string)

	log.Printf("Admin %s menghapus (soft delete) user ID %s", username, id)

	err := repository.SoftDeleteUserAndRelated(db, id)
	if err != nil {
		if err == sql.ErrNoRows {
			return c.Status(fiber.StatusNotFound).JSON(fiber.Map{
				"message": "User tidak ditemukan atau sudah dihapus",
				"success": false,
			})
		}
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
			"message": "Gagal menghapus user: " + err.Error(),
			"success": false,
		})
	}

	return c.Status(fiber.StatusOK).JSON(fiber.Map{
		"message": "User berhasil dihapus (soft delete)",
		"success": true,
	})
}

// Semua fungsi lama yang tidak relevan dengan SRS baru dihilangkan atau diganti dengan placeholder.
func GetAlumniStatisticsService(c *fiber.Ctx, db *sql.DB) error {
	return c.Status(fiber.StatusNotImplemented).JSON(fiber.Map{
		"message": "Endpoint statistik belum diimplementasi untuk model baru",
		"success": false,
	})
}

func GetAllAlumniWithPaginationService(c *fiber.Ctx, db *sql.DB) error {
	return c.Status(fiber.StatusNotImplemented).JSON(fiber.Map{
		"message": "Endpoint pagination belum diimplementasi untuk model baru",
		"success": false,
	})
}

func GetTrashedAlumniService(c *fiber.Ctx, db *sql.DB) error {
	return c.Status(fiber.StatusNotImplemented).JSON(fiber.Map{
		"message": "Endpoint trash belum diimplementasi untuk model baru",
		"success": false,
	})
}

func SoftDeleteAlumniService(c *fiber.Ctx, db *sql.DB) error {
	return c.Status(fiber.StatusNotImplemented).JSON(fiber.Map{
		"message": "Endpoint soft-delete belum diimplementasi untuk model baru",
		"success": false,
	})
}

func RestoreAlumniService(c *fiber.Ctx, db *sql.DB) error {
	return c.Status(fiber.StatusNotImplemented).JSON(fiber.Map{
		"message": "Endpoint restore belum diimplementasi untuk model baru",
		"success": false,
	})
}

func HardDeleteAlumniService(c *fiber.Ctx, db *sql.DB) error {
	return c.Status(fiber.StatusNotImplemented).JSON(fiber.Map{
		"message": "Endpoint hard-delete belum diimplementasi untuk model baru",
		"success": false,
	})
}
