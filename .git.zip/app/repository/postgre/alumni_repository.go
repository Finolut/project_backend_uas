package repository

import (
	model "clean-arch/app/model/postgre"
	"database/sql"
	"time"
)

// GetAllStudents fetches all active students along with their User details.
func GetAllStudents(db *sql.DB) ([]struct {
	model.User
	model.Student
}, error) {
	query := `SELECT 
	          u.id, u.username, u.email, u.full_name, u.role_id, u.is_active, u.created_at, u.updated_at,
	          s.id, s.student_id, s.program_study, s.academic_year, s.advisor_id, s.created_at
	          FROM users u
	          JOIN students s ON u.id = s.user_id
			  WHERE u.is_active = TRUE`

	rows, err := db.Query(query)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var studentList []struct {
		model.User
		model.Student
	}
	for rows.Next() {
		var u model.User
		var s model.Student
		var sCreatedAt time.Time

		err := rows.Scan(
			&u.ID, &u.Username, &u.Email, &u.FullName, &u.RoleID, &u.IsActive, &u.CreatedAt, &u.UpdatedAt,
			&s.ID, &s.StudentID, &s.ProgramStudy, &s.AcademicYear, &s.AdvisorID, &sCreatedAt,
		)
		if err != nil {
			return nil, err
		}
		s.CreatedAt = sCreatedAt

		studentList = append(studentList, struct {
			model.User
			model.Student
		}{u, s})
	}
	return studentList, nil
}

// GetStudentByUserID fetches a Student record by their linked User ID.
func GetStudentByUserID(db *sql.DB, userID string) (*model.Student, error) {
	var student model.Student
	query := `SELECT id, user_id, student_id, program_study, academic_year, advisor_id, created_at 
	          FROM students WHERE user_id = $1`

	err := db.QueryRow(query, userID).Scan(
		&student.ID, &student.UserID, &student.StudentID, &student.ProgramStudy,
		&student.AcademicYear, &student.AdvisorID, &student.CreatedAt,
	)
	if err != nil {
		return nil, err
	}
	return &student, nil
}

// UpdateUserAndStudent updates both User and Student details.
func UpdateUserAndStudent(db *sql.DB, userID string, req model.UpdateStudentRequest) (*model.User, *model.Student, error) {
	tx, err := db.Begin()
	if err != nil {
		return nil, nil, err
	}
	defer tx.Rollback()

	// 1. Update User
	userQuery := `UPDATE users SET email = $1, full_name = $2, updated_at = NOW() WHERE id = $3 RETURNING id, username, email, full_name, role_id, is_active, created_at, updated_at`

	var user model.User
	err = tx.QueryRow(userQuery, req.Email, req.FullName, userID).Scan(
		&user.ID, &user.Username, &user.Email, &user.FullName, &user.RoleID, &user.IsActive, &user.CreatedAt, &user.UpdatedAt,
	)
	if err != nil {
		return nil, nil, err
	}

	// 2. Update Student
	studentQuery := `UPDATE students SET program_study = $1, academic_year = $2 WHERE user_id = $3 RETURNING id, user_id, student_id, program_study, academic_year, advisor_id, created_at`

	var student model.Student
	err = tx.QueryRow(studentQuery, req.ProgramStudy, req.AcademicYear, userID).Scan(
		&student.ID, &student.UserID, &student.StudentID, &student.ProgramStudy, &student.AcademicYear, &student.AdvisorID, &student.CreatedAt,
	)
	if err != nil {
		// Jika tidak ada entry di tabel students (misal user adalah Lecturer/Admin), abaikan error sql.ErrNoRows
		if err != sql.ErrNoRows {
			return nil, nil, err
		}
	}

	if err := tx.Commit(); err != nil {
		return nil, nil, err
	}

	return &user, &student, nil
}

// SoftDeleteUserAndRelated performs soft delete on User (by setting is_active = FALSE)
func SoftDeleteUserAndRelated(db *sql.DB, userID string) error {
	// Set is_active=false on the user for soft delete
	query := `UPDATE users SET is_active = FALSE, updated_at = NOW() WHERE id = $1 AND is_active = TRUE`
	result, err := db.Exec(query, userID)
	if err != nil {
		return err
	}

	rowsAffected, _ := result.RowsAffected()
	if rowsAffected == 0 {
		return sql.ErrNoRows // Or specific error indicating user not found/already deleted
	}
	return nil
}

// CheckStudentByStudentID checks if a student with the given NIM exists and is active.
func CheckStudentByStudentID(db *sql.DB, studentID string) (*model.Student, *model.User, error) {
	var student model.Student
	var user model.User

	query := `SELECT 
	          u.id, u.username, u.email, u.full_name, u.role_id, u.is_active, 
	          s.id, s.student_id, s.program_study, s.academic_year, s.advisor_id
	          FROM students s
	          JOIN users u ON s.user_id = u.id
	          WHERE s.student_id = $1 AND u.is_active = TRUE`

	err := db.QueryRow(query, studentID).Scan(
		&user.ID, &user.Username, &user.Email, &user.FullName, &user.RoleID, &user.IsActive,
		&student.ID, &student.StudentID, &student.ProgramStudy, &student.AcademicYear, &student.AdvisorID,
	)
	if err != nil {
		return nil, nil, err
	}
	return &student, &user, nil
}
