package repository

import (
	// Perbaikan: Mengacu ke package model di dalam path.
	model "clean-arch/app/model/postgre"
	"database/sql"
)

const achievementReferenceCollection = "achievement_references"

// GetAllAchievementReferences fetches all achievement references
func GetAllAchievementReferences(db *sql.DB) ([]model.AchievementReference, error) {
	query := `SELECT id, student_id, mongo_achievement_id, status, submitted_at, verified_at, verified_by, rejection_note, created_at, updated_at 
	          FROM achievement_references ORDER BY created_at DESC`

	rows, err := db.Query(query)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var list []model.AchievementReference
	for rows.Next() {
		var ref model.AchievementReference
		err := rows.Scan(
			&ref.ID, &ref.StudentID, &ref.MongoAchievementID, &ref.Status,
			&ref.SubmittedAt, &ref.VerifiedAt, &ref.VerifiedBy, &ref.RejectionNote,
			&ref.CreatedAt, &ref.UpdatedAt,
		)
		if err != nil {
			return nil, err
		}
		list = append(list, ref)
	}
	return list, nil
}

// GetAchievementReferenceByID fetches a single achievement reference by ID
func GetAchievementReferenceByID(db *sql.DB, id string) (*model.AchievementReference, error) {
	var ref model.AchievementReference
	query := `SELECT id, student_id, mongo_achievement_id, status, submitted_at, verified_at, verified_by, rejection_note, created_at, updated_at 
	          FROM achievement_references WHERE id = $1`

	err := db.QueryRow(query, id).Scan(
		&ref.ID, &ref.StudentID, &ref.MongoAchievementID, &ref.Status,
		&ref.SubmittedAt, &ref.VerifiedAt, &ref.VerifiedBy, &ref.RejectionNote,
		&ref.CreatedAt, &ref.UpdatedAt,
	)
	if err != nil {
		return nil, err
	}
	return &ref, nil
}

// GetAllPekerjaanWithPagination is kept as a placeholder to avoid compilation error on routes, but returns dummy data.
func GetAllPekerjaanWithPagination(db *sql.DB, params model.PaginationParams) ([]model.AchievementReference, int, error) {
	return nil, 0, nil
}
