package config

import (
	"database/sql"
	"log"

	service "clean-arch/app/service/postgre"
	middleware "clean-arch/middleware/postgre"

	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/cors"
)

func NewApp(db *sql.DB) *fiber.App {
	app := fiber.New()

	app.Use(cors.New())
	app.Use(middleware.LoggerMiddleware)

	app.Static("/", "./public")

	app.Get("/", func(c *fiber.Ctx) error {
		return c.SendFile("./public/index.html")
	})

	api := app.Group("/api")

	api.Get("/checkpoint", func(c *fiber.Ctx) error {
		// Menggunakan service.CheckpointService dari health_service.go
		return service.CheckpointService(c, db)
	})

	api.Post("/login", func(c *fiber.Ctx) error {
		// Menggunakan service.LoginService dari auth_service.go
		return service.LoginService(c, db)
	})

	protected := api.Group("", middleware.AuthRequired())
	protected.Get("/profile", func(c *fiber.Ctx) error {
		return service.GetProfileService(c, db)
	})

	// PERBAIKAN: Mengganti grup '/alumni' menjadi '/student'
	student := protected.Group("/student")

	// GET /api/student
	student.Get("/", func(c *fiber.Ctx) error {
		// PERBAIKAN: Mengganti GetAllAlumniService -> GetAllStudentsService
		return service.GetAllStudentsService(c, db)
	})

	// GET /api/student/:id
	student.Get("/:id", func(c *fiber.Ctx) error {
		// PERBAIKAN: Mengganti GetAlumniByIDService -> GetStudentByIDService
		return service.GetStudentByIDService(c, db)
	})

	// POST /api/student (Admin Only)
	student.Post("/", middleware.AdminOnly(), func(c *fiber.Ctx) error {
		// PERBAIKAN: Mengganti CreateAlumniService -> CreateStudentService
		return service.CreateStudentService(c, db)
	})

	// PUT /api/student/:id (Admin Only)
	student.Put("/:id", middleware.AdminOnly(), func(c *fiber.Ctx) error {
		// PERBAIKAN: Mengganti UpdateAlumniService -> UpdateStudentService
		return service.UpdateStudentService(c, db)
	})

	// DELETE /api/student/:id (Admin Only - Soft Delete User)
	student.Delete("/:id", middleware.AdminOnly(), func(c *fiber.Ctx) error {
		// PERBAIKAN: Mengganti DeleteAlumniService -> DeleteStudentService
		return service.DeleteStudentService(c, db)
	})

	// TRASH/SOFT DELETE Operations (Fungsi Service masih mempertahankan nama lama untuk placeholder)
	student.Get("/trash", middleware.AdminOnly(), func(c *fiber.Ctx) error {
		return service.GetTrashedAlumniService(c, db)
	})
	student.Post("/:id/soft-delete", middleware.AdminOnly(), func(c *fiber.Ctx) error {
		return service.SoftDeleteAlumniService(c, db)
	})
	student.Post("/:id/restore", middleware.AdminOnly(), func(c *fiber.Ctx) error {
		return service.RestoreAlumniService(c, db)
	})
	student.Delete("/:id/permanent", middleware.AdminOnly(), func(c *fiber.Ctx) error {
		return service.HardDeleteAlumniService(c, db)
	})

	// Pekerjaan Endpoints
	pekerjaan := protected.Group("/pekerjaan")
	pekerjaan.Get("/", func(c *fiber.Ctx) error {
		return service.GetAllPekerjaanService(c, db)
	})
	pekerjaan.Get("/:id", func(c *fiber.Ctx) error {
		return service.GetPekerjaanByIDService(c, db)
	})
	// PERBAIKAN: Mengganti rute /alumni/:alumni_id menjadi /student/:user_id (atau student_id)
	pekerjaan.Get("/student/:user_id", middleware.AdminOnly(), func(c *fiber.Ctx) error {
		// Fungsi service masih menggunakan nama lama (GetPekerjaanByAlumniIDService)
		return service.GetPekerjaanByAlumniIDService(c, db)
	})
	pekerjaan.Post("/", middleware.AdminOnly(), func(c *fiber.Ctx) error {
		return service.CreatePekerjaanService(c, db)
	})
	pekerjaan.Put("/:id", middleware.AdminOnly(), func(c *fiber.Ctx) error {
		return service.UpdatePekerjaanService(c, db)
	})
	pekerjaan.Delete("/:id", middleware.AdminOnly(), func(c *fiber.Ctx) error {
		return service.DeletePekerjaanService(c, db)
	})

	cleanarch := protected.Group("/cleanarch")
	// PERBAIKAN: Mengganti rute /alumni menjadi /student
	log.Println("Registering /api/cleanarch/student route")
	cleanarch.Get("/student", func(c *fiber.Ctx) error {
		log.Println("Accessing /api/cleanarch/student endpoint")
		return service.GetAllAlumniWithPaginationService(c, db) // Placeholder function
	})
	log.Println("Registering /api/cleanarch/pekerjaan route")
	cleanarch.Get("/pekerjaan", func(c *fiber.Ctx) error {
		log.Println("Accessing /api/cleanarch/pekerjaan endpoint")
		return service.GetAllPekerjaanWithPaginationService(c, db)
	})

	// Logging output disesuaikan
	log.Println("All routes registered successfully:")
	log.Println("- POST /api/login")
	log.Println("- GET /api/profile (protected)")
	log.Println("- GET /api/student (protected)")
	log.Println("- GET /api/student/:id (protected)")
	log.Println("- POST /api/student (admin only)")
	log.Println("- PUT /api/student/:id (admin only)")
	log.Println("- DELETE /api/student/:id (admin only)")
	log.Println("- GET /api/pekerjaan (protected)")
	log.Println("- GET /api/pekerjaan/:id (protected)")
	log.Println("- GET /api/pekerjaan/student/:user_id (admin only)")
	log.Println("- GET /api/cleanarch/student (protected, with pagination)")
	log.Println("- POST /check/:key (legacy)")

	return app
}
