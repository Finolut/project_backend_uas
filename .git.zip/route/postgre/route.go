package route

import (
	"database/sql"

	service "clean-arch/app/service/postgre"
	middleware "clean-arch/middleware/postgre"

	"github.com/gofiber/fiber/v2"
)

func RegisterRoutes(app *fiber.App, db *sql.DB) {

	// --- RUTE PUBLIC (TIDAK MEMBUTUHKAN TOKEN) ---

	// Auth Umum (Admin/Dosen Wali/Sistem)
	app.Post("/auth/login", func(c *fiber.Ctx) error {
		return service.LoginService(c, db)
	})

	// Student/Mahasiswa - Register & Login
	app.Post("/student/register", func(c *fiber.Ctx) error {
		return service.RegisterStudentService(c, db)
	})

	// PERBAIKAN: Memastikan login mahasiswa ada di public group
	app.Post("/student/login", func(c *fiber.Ctx) error {
		return service.StudentLoginService(c, db)
	})

	// Legacy check route
	app.Post("/check/:key", func(c *fiber.Ctx) error {
		return service.CheckStudentService(c, db)
	})

	// --- RUTE PROTECTED (MEMBUTUHKAN TOKEN) ---

	// Protected group untuk user non-mahasiswa (Admin/Dosen Wali)
	protectedUser := app.Group("/api/user", middleware.AuthRequired())
	protectedUser.Get("/profile", func(c *fiber.Ctx) error {
		return service.GetProfileService(c, db)
	})

	// Protected group untuk mahasiswa (Token Student/Alumni)
	protectedStudent := app.Group("/api/student", middleware.StudentAuthRequired())
	protectedStudent.Get("/profile", func(c *fiber.Ctx) error {
		return service.GetStudentProfileService(c, db)
	})

	// --- RUTE MAHASISWA (CRUD) ---
	// Rute CRUD dan pengelolaan data Mahasiswa biasanya butuh token umum (Admin/Dosen Wali)
	// Kita akan menggunakan rute dari config/postgre/app.go di mana middleware sudah diterapkan di grup /student.
	// Jika Anda menggunakan struktur modular, kita harus memastikan semua rute di config/postgre/app.go sudah dipindahkan ke sini atau terorganisir dengan benar.

	// Mengasumsikan endpoint CRUD student (yang perlu admin only) berada di grup app.Group("/api/student")
	// Karena kita telah merefactor config/postgre/app.go untuk menggunakan rute baru, mari kita gunakan struktur yang lebih ringkas di sini.

	// Rute-rute lanjutan yang memerlukan token AuthRequired() atau StudentAuthRequired() seharusnya didefinisikan di sini.
	// Untuk menjaga konsistensi dengan refactoring yang sudah kita lakukan sebelumnya di config/postgre/app.go:

	// Menggunakan grup API standar yang membutuhkan AuthRequired (Admin, Dosen Wali)
	protected := app.Group("/api", middleware.AuthRequired())

	student := protected.Group("/student")
	student.Get("/", func(c *fiber.Ctx) error { return service.GetAllStudentsService(c, db) })
	student.Get("/:id", func(c *fiber.Ctx) error { return service.GetStudentByIDService(c, db) })
	student.Post("/", middleware.AdminOnly(), func(c *fiber.Ctx) error { return service.CreateStudentService(c, db) })
	student.Put("/:id", middleware.AdminOnly(), func(c *fiber.Ctx) error { return service.UpdateStudentService(c, db) })
	student.Delete("/:id", middleware.AdminOnly(), func(c *fiber.Ctx) error { return service.DeleteStudentService(c, db) })

	// Placeholder routes (juga butuh token)
	student.Get("/trash", middleware.AdminOnly(), func(c *fiber.Ctx) error { return service.GetTrashedAlumniService(c, db) })
	student.Post("/:id/soft-delete", middleware.AdminOnly(), func(c *fiber.Ctx) error { return service.SoftDeleteAlumniService(c, db) })

	// ... dan rute pekerjaan (jika sudah di-refactor ke route.go)

}
