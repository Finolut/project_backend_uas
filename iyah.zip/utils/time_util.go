package utils

import "time"

// GetNowTime returns current time
func GetNowTime() time.Time {
	return time.Now()
}
